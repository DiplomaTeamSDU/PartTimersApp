$(document).ready(function() {
    $("button#add-skills-btn-id").click(function() {
        $("div#add-skills-container-id").toggle();
    });
});